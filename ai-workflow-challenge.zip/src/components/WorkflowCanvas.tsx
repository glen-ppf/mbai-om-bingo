import { useState, useEffect, useRef } from 'react';
import { motion } from 'motion/react';
import { ScenarioData } from '../data';
import NodeCard from './NodeCard';

interface WorkflowCanvasProps {
  scenario: ScenarioData;
  exploredNodes: Set<string>;
  optimalFound: boolean;
  onNodeClick: (id: string, isOptimal: boolean) => void;
  isWrongShake: boolean;
}

export default function WorkflowCanvas({
  scenario,
  exploredNodes,
  optimalFound,
  onNodeClick,
  isWrongShake,
}: WorkflowCanvasProps) {
  const containerRef = useRef<HTMLDivElement>(null);
  const [dimensions, setDimensions] = useState({ width: 0, height: 0 });

  useEffect(() => {
    const updateDimensions = () => {
      if (containerRef.current) {
        setDimensions({
          width: containerRef.current.scrollWidth,
          height: containerRef.current.scrollHeight,
        });
      }
    };

    updateDimensions();
    window.addEventListener('resize', updateDimensions);
    return () => window.removeEventListener('resize', updateDimensions);
  }, [scenario.id]);

  // Define layouts based on scenario ID
  const getLayout = () => {
    const cardWidth = 280;
    const cardHeight = 320;
    const gapX = 120;
    const gapY = 80;

    switch (scenario.id) {
      case 'invoice-processing':
        // 1 -> 2 -> (3, 4) -> 5 -> 6 -> 7
        return {
          nodes: [
            { id: '1-1', x: 0, y: cardHeight / 2 + gapY / 2 },
            { id: '1-2', x: cardWidth + gapX, y: cardHeight / 2 + gapY / 2 },
            { id: '1-3', x: (cardWidth + gapX) * 2, y: 0 },
            { id: '1-4', x: (cardWidth + gapX) * 2, y: cardHeight + gapY },
            { id: '1-5', x: (cardWidth + gapX) * 3, y: cardHeight / 2 + gapY / 2 },
            { id: '1-6', x: (cardWidth + gapX) * 4, y: cardHeight / 2 + gapY / 2 },
            { id: '1-7', x: (cardWidth + gapX) * 5, y: cardHeight / 2 + gapY / 2 },
          ],
          connections: [
            { from: '1-1', to: '1-2' },
            { from: '1-2', to: '1-3' },
            { from: '1-2', to: '1-4' },
            { from: '1-3', to: '1-5' },
            { from: '1-4', to: '1-5' },
            { from: '1-5', to: '1-6' },
            { from: '1-6', to: '1-7' },
          ],
          width: (cardWidth + gapX) * 5 + cardWidth,
          height: cardHeight * 2 + gapY,
        };
      case 'supply-chain':
        // Zig-zag pipeline
        // 1 -> 2 -> 3
        //           |
        // 6 <- 5 <- 4
        return {
          nodes: [
            { id: '2-1', x: 0, y: 0 },
            { id: '2-2', x: cardWidth + gapX, y: 0 },
            { id: '2-3', x: (cardWidth + gapX) * 2, y: 0 },
            { id: '2-4', x: (cardWidth + gapX) * 2, y: cardHeight + gapY },
            { id: '2-5', x: cardWidth + gapX, y: cardHeight + gapY },
            { id: '2-6', x: 0, y: cardHeight + gapY },
          ],
          connections: [
            { from: '2-1', to: '2-2' },
            { from: '2-2', to: '2-3' },
            { from: '2-3', to: '2-4', type: 'vertical' },
            { from: '2-4', to: '2-5', type: 'reverse' },
            { from: '2-5', to: '2-6', type: 'reverse' },
          ],
          width: (cardWidth + gapX) * 2 + cardWidth,
          height: cardHeight * 2 + gapY,
        };
      case 'customer-support':
        // Diamond fan-out/fan-in or feedback loops
        // 1 -> 2 -> 3 -> 4 -> 5 -> 6
        //      |--------------^
        //      ^--------------| (feedback)
        return {
          nodes: [
            { id: '3-1', x: 0, y: cardHeight / 2 + gapY / 2 },
            { id: '3-2', x: cardWidth + gapX, y: cardHeight / 2 + gapY / 2 },
            { id: '3-3', x: (cardWidth + gapX) * 2, y: 0 },
            { id: '3-4', x: (cardWidth + gapX) * 3, y: 0 },
            { id: '3-5', x: (cardWidth + gapX) * 4, y: cardHeight / 2 + gapY / 2 },
            { id: '3-6', x: (cardWidth + gapX) * 5, y: cardHeight / 2 + gapY / 2 },
          ],
          connections: [
            { from: '3-1', to: '3-2' },
            { from: '3-2', to: '3-3' },
            { from: '3-3', to: '3-4' },
            { from: '3-4', to: '3-5' },
            { from: '3-2', to: '3-5', type: 'straight' }, // Fast track
            { from: '3-5', to: '3-2', type: 'feedback' }, // Feedback loop
            { from: '3-5', to: '3-6' },
          ],
          width: (cardWidth + gapX) * 5 + cardWidth,
          height: cardHeight * 2 + gapY,
        };
      default:
        return { nodes: [], connections: [], width: 0, height: 0 };
    }
  };

  const layout = getLayout();
  const cardWidth = 280;
  const cardHeight = 320;

  const generatePath = (conn: any, nodes: any[]) => {
    const fromNode = nodes.find((n) => n.id === conn.from);
    const toNode = nodes.find((n) => n.id === conn.to);

    if (!fromNode || !toNode) return '';

    const startX = fromNode.x + cardWidth;
    const startY = fromNode.y + cardHeight / 2;
    const endX = toNode.x;
    const endY = toNode.y + cardHeight / 2;

    if (conn.type === 'vertical') {
      const startX = fromNode.x + cardWidth / 2;
      const startY = fromNode.y + cardHeight;
      const endX = toNode.x + cardWidth / 2;
      const endY = toNode.y;
      return `M ${startX} ${startY} C ${startX} ${startY + 40}, ${endX} ${endY - 40}, ${endX} ${endY}`;
    }

    if (conn.type === 'reverse') {
      const startX = fromNode.x;
      const startY = fromNode.y + cardHeight / 2;
      const endX = toNode.x + cardWidth;
      const endY = toNode.y + cardHeight / 2;
      return `M ${startX} ${startY} C ${startX - 40} ${startY}, ${endX + 40} ${endY}, ${endX} ${endY}`;
    }

    if (conn.type === 'feedback') {
      const startX = fromNode.x + cardWidth / 2;
      const startY = fromNode.y + cardHeight;
      const endX = toNode.x + cardWidth / 2;
      const endY = toNode.y + cardHeight;
      return `M ${startX} ${startY} C ${startX} ${startY + 100}, ${endX} ${endY + 100}, ${endX} ${endY}`;
    }

    if (conn.type === 'straight') {
      return `M ${startX} ${startY} L ${endX} ${endY}`;
    }

    // Default curved path (horizontal)
    const midX = startX + (endX - startX) / 2;
    return `M ${startX} ${startY} C ${midX} ${startY}, ${midX} ${endY}, ${endX} ${endY}`;
  };

  return (
    <div
      ref={containerRef}
      className="relative w-full h-full min-h-full p-12"
      style={{
        minWidth: `${layout.width + 96}px`,
        minHeight: `${layout.height + 96}px`,
      }}
    >
      {/* SVG Connections Layer */}
      <svg
        className="absolute top-12 left-12 pointer-events-none z-0"
        width={layout.width}
        height={layout.height}
        style={{ overflow: 'visible' }}
      >
        <defs>
          <marker
            id="arrowhead"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="#A6335F" opacity="0.5" />
          </marker>
          <marker
            id="arrowhead-reverse"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="#FDBF57" opacity="0.5" />
          </marker>
          <marker
            id="arrowhead-feedback"
            markerWidth="10"
            markerHeight="7"
            refX="9"
            refY="3.5"
            orient="auto"
          >
            <polygon points="0 0, 10 3.5, 0 7" fill="#3D9970" opacity="0.5" />
          </marker>
        </defs>
        {layout.connections.map((conn, i) => {
          const path = generatePath(conn, layout.nodes);
          let markerId = 'arrowhead';
          let strokeColor = '#A6335F';

          if (scenario.id === 'supply-chain') {
            markerId = 'arrowhead-reverse';
            strokeColor = '#FDBF57';
          } else if (scenario.id === 'customer-support') {
            markerId = 'arrowhead-feedback';
            strokeColor = '#3D9970';
          }

          return (
            <motion.path
              key={`${conn.from}-${conn.to}`}
              d={path}
              fill="none"
              stroke={strokeColor}
              strokeWidth="3"
              strokeOpacity="0.3"
              strokeDasharray="6 6"
              markerEnd={`url(#${markerId})`}
              initial={{ pathLength: 0, opacity: 0 }}
              animate={{ pathLength: 1, opacity: 1 }}
              transition={{ duration: 1.5, delay: i * 0.2, ease: 'easeInOut' }}
            />
          );
        })}
      </svg>

      {/* Nodes Layer */}
      <div className="relative z-10 w-full h-full">
        {scenario.nodes.map((node, index) => {
          const pos = layout.nodes.find((n) => n.id === node.id);
          if (!pos) return null;

          return (
            <motion.div
              key={node.id}
              className="absolute"
              style={{ left: pos.x, top: pos.y }}
              initial={{ opacity: 0, scale: 0.8, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              transition={{ duration: 0.5, delay: index * 0.1, type: 'spring' }}
            >
              <NodeCard
                node={node}
                index={index}
                isExplored={exploredNodes.has(node.id)}
                isOptimalFound={optimalFound}
                onClick={onNodeClick}
                isWrongShake={isWrongShake && exploredNodes.has(node.id)}
              />
            </motion.div>
          );
        })}
      </div>
    </div>
  );
}
