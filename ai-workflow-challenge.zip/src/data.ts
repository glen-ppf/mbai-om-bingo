import {
  ClipboardList,
  FileText,
  Package,
  Mail,
  Search,
  CheckCircle2,
  DollarSign,
  BarChart3,
  Target,
  Handshake,
  Factory,
  Store,
  Truck,
  Ticket,
  Tag,
  User,
  Star,
  LucideIcon
} from 'lucide-react';

export type NodeData = {
  id: string;
  title: string;
  description: string;
  icon: LucideIcon;
  isOptimal: boolean;
  aiExplanation: string;
  impact: string;
  color: string;
};

export type ScenarioData = {
  id: string;
  title: string;
  context: string;
  themeGradient: string;
  icon: LucideIcon;
  nodes: NodeData[];
};

export const PASTEL_COLORS = [
  '#DB2777', // pink
  '#D97706', // amber
  '#16A34A', // green
  '#E11D48', // rose
  '#7C3AED', // violet
  '#EA580C', // orange
  '#0284C7', // sky blue
  '#9333EA', // purple
];

export const SCENARIOS: ScenarioData[] = [
  {
    id: 'invoice-processing',
    title: 'Invoice Processing & Accounts Payable',
    context: 'Mid-size manufacturing company, 2,000+ invoices/month, 150+ suppliers, AP team of 6 drowning. 45-day payment cycle, 12% error rate, 70% time on manual entry.',
    themeGradient: 'from-[#7A003C] to-[#A6335F]',
    icon: FileText,
    nodes: [
      {
        id: '1-1',
        title: 'Purchase Request',
        description: 'Employee submits request for goods.',
        icon: ClipboardList,
        isOptimal: false,
        aiExplanation: 'AI can help draft requests, but this is low volume and low impact.',
        impact: 'Saves a few minutes per request.',
        color: PASTEL_COLORS[0],
      },
      {
        id: '1-2',
        title: 'PO Created',
        description: 'Procurement generates Purchase Order.',
        icon: FileText,
        isOptimal: false,
        aiExplanation: 'RPA can automate PO generation, but it doesn\'t solve the matching bottleneck.',
        impact: 'Reduces manual data entry slightly.',
        color: PASTEL_COLORS[1],
      },
      {
        id: '1-3',
        title: 'Goods Received',
        description: 'Warehouse logs received items.',
        icon: Package,
        isOptimal: false,
        aiExplanation: 'Computer vision can scan barcodes, but the real issue is reconciling this data later.',
        impact: 'Faster receiving, but AP still struggles.',
        color: PASTEL_COLORS[2],
      },
      {
        id: '1-4',
        title: 'Invoice Received',
        description: 'Supplier sends invoice to AP.',
        icon: Mail,
        isOptimal: false,
        aiExplanation: 'OCR can extract text from PDFs, but without matching, it just creates digital clutter.',
        impact: 'Eliminates re-typing, but not the cognitive load.',
        color: PASTEL_COLORS[3],
      },
      {
        id: '1-5',
        title: '3-Way Match',
        description: 'Match PO, Receipt, and Invoice.',
        icon: Search,
        isOptimal: true,
        aiExplanation: 'AI auto-matches POs, receipts, and invoices handling fuzzy text and line-item variations.',
        impact: '70-90% of invoices auto-matched, processing drops from days to hours.',
        color: PASTEL_COLORS[4],
      },
      {
        id: '1-6',
        title: 'Approval Routing',
        description: 'Send exceptions for manager approval.',
        icon: CheckCircle2,
        isOptimal: false,
        aiExplanation: 'AI can predict who should approve, but standard rules engines already do this well.',
        impact: 'Slightly faster routing.',
        color: PASTEL_COLORS[5],
      },
      {
        id: '1-7',
        title: 'Payment Sent',
        description: 'Funds transferred to supplier.',
        icon: DollarSign,
        isOptimal: false,
        aiExplanation: 'Payment scheduling is a solved problem with standard ERP systems.',
        impact: 'Minimal operational impact.',
        color: PASTEL_COLORS[6],
      },
    ],
  },
  {
    id: 'supply-chain',
    title: 'Supply Chain — Forecast to Fulfillment',
    context: 'National retail chain, 200+ stores, popular items stock out in 3 days ($2M/quarter lost), $15M in dead inventory, bullwhip effect.',
    themeGradient: 'from-[#B8860B] to-[#FDBF57]',
    icon: Truck,
    nodes: [
      {
        id: '2-1',
        title: 'Data Collection',
        description: 'Gather sales and market data.',
        icon: BarChart3,
        isOptimal: false,
        aiExplanation: 'AI can clean data, but collecting data isn\'t the core problem—using it is.',
        impact: 'Better data quality, but no direct ROI.',
        color: PASTEL_COLORS[0],
      },
      {
        id: '2-2',
        title: 'Demand Forecasting',
        description: 'Predict future product demand.',
        icon: Target,
        isOptimal: true,
        aiExplanation: 'ML models analyze weather, trends, and history to predict demand with high accuracy.',
        impact: 'Reduces forecast error 30-50%, cascading improvement through entire supply chain.',
        color: PASTEL_COLORS[1],
      },
      {
        id: '2-3',
        title: 'Procurement',
        description: 'Order raw materials/products.',
        icon: Handshake,
        isOptimal: false,
        aiExplanation: 'AI can suggest suppliers, but if the forecast is wrong, you buy the wrong things.',
        impact: 'Marginal cost savings on materials.',
        color: PASTEL_COLORS[2],
      },
      {
        id: '2-4',
        title: 'Production',
        description: 'Manufacture or assemble goods.',
        icon: Factory,
        isOptimal: false,
        aiExplanation: 'Predictive maintenance helps, but doesn\'t solve the $15M dead inventory issue.',
        impact: 'Less machine downtime.',
        color: PASTEL_COLORS[3],
      },
      {
        id: '2-5',
        title: 'Warehousing',
        description: 'Store goods until needed.',
        icon: Store,
        isOptimal: false,
        aiExplanation: 'Robotics optimize picking, but storing the wrong items is still a waste.',
        impact: 'Faster fulfillment, but high holding costs remain.',
        color: PASTEL_COLORS[4],
      },
      {
        id: '2-6',
        title: 'Distribution',
        description: 'Ship products to stores.',
        icon: Truck,
        isOptimal: false,
        aiExplanation: 'Route optimization saves fuel, but doesn\'t fix stockouts of popular items.',
        impact: 'Lower shipping costs.',
        color: PASTEL_COLORS[5],
      },
    ],
  },
  {
    id: 'customer-support',
    title: 'Customer Support Ticket Resolution',
    context: 'B2B SaaS, 500+ tickets/day, response time 14hrs (SLA 4hrs), satisfaction 3.1 stars, 18% churn.',
    themeGradient: 'from-[#2E6B4F] to-[#3D9970]',
    icon: Ticket,
    nodes: [
      {
        id: '3-1',
        title: 'Ticket Submitted',
        description: 'Customer emails or uses portal.',
        icon: Ticket,
        isOptimal: false,
        aiExplanation: 'Chatbots can deflect some tickets, but B2B SaaS issues are often too complex.',
        impact: 'Minor deflection rate.',
        color: PASTEL_COLORS[0],
      },
      {
        id: '3-2',
        title: 'Triage & Categorize',
        description: 'Read, tag, and prioritize ticket.',
        icon: Tag,
        isOptimal: true,
        aiExplanation: 'NLP auto-classifies with 95%+ accuracy, instantly routing to the right expert or auto-resolving.',
        impact: 'Auto-resolves 30-40% of simple tickets instantly, slashes response time.',
        color: PASTEL_COLORS[1],
      },
      {
        id: '3-3',
        title: 'Agent Assignment',
        description: 'Assign to available support rep.',
        icon: User,
        isOptimal: false,
        aiExplanation: 'Round-robin or basic rules work fine if the ticket is already categorized correctly.',
        impact: 'Slightly better workload balancing.',
        color: PASTEL_COLORS[2],
      },
      {
        id: '3-4',
        title: 'Investigation',
        description: 'Agent researches the issue.',
        icon: Search,
        isOptimal: false,
        aiExplanation: 'AI search helps agents find docs, but the bottleneck is getting the ticket to them.',
        impact: 'Faster resolution time per ticket.',
        color: PASTEL_COLORS[3],
      },
      {
        id: '3-5',
        title: 'Resolution',
        description: 'Agent replies with fix.',
        icon: CheckCircle2,
        isOptimal: false,
        aiExplanation: 'Generative AI can draft replies, but agents still need to verify technical accuracy.',
        impact: 'Saves typing time.',
        color: PASTEL_COLORS[4],
      },
      {
        id: '3-6',
        title: 'Follow-up & CSAT',
        description: 'Ask customer for feedback.',
        icon: Star,
        isOptimal: false,
        aiExplanation: 'Automated surveys handle this entirely; AI adds little value here.',
        impact: 'No significant operational change.',
        color: PASTEL_COLORS[5],
      },
    ],
  }
];
